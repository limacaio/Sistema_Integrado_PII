package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Controller.CategoriaController;
import Controller.SituacaoController;
import Controller.UsuarioController;
import Controller.VendaController;
import Model.Categoria;
import Model.Situacao;
import Model.Usuario;
import Model.Venda;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class GerSituacao extends JFrame {
	
	private JButton btnAtualizar;
	private JPanel contentPane;
	private JTable tblSituacao;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GerSituacao frame = new GerSituacao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GerSituacao() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 545, 304);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 532, 272);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(18, 45, 477, 75);
		panel.add(scrollPane);
		JComboBox cmbSituacao = new JComboBox();
		cmbSituacao.addItem("");
		SituacaoController sitControl = new SituacaoController();
		for (Map.Entry<Integer,Situacao> pair : sitControl.buscarSituacaoController().entrySet()) {
			
			cmbSituacao.addItem(pair.getValue().getDescricao());
		}
		cmbSituacao.setBounds(18, 183, 477, 20);
		panel.add(cmbSituacao);
		tblSituacao = new JTable();
		tblSituacao.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				if(tblSituacao.getSelectedRow() != -1) {
					DefaultTableModel modelo = (DefaultTableModel)tblSituacao.getModel();
					
					cmbSituacao.setSelectedItem(modelo.getValueAt(tblSituacao.getSelectedRow(), 3));
					
			
				}
			}
		});
		
		scrollPane.setViewportView(tblSituacao);
		tblSituacao.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"IDVenda", "Data da Venda", "Cliente", "Situa\u00E7\u00E3o"
			}
		));
		tblSituacao.getColumnModel().getColumn(0).setPreferredWidth(0);
		tblSituacao.getColumnModel().getColumn(0).setMinWidth(0);
		tblSituacao.getColumnModel().getColumn(0).setMaxWidth(0);
		tblSituacao.getColumnModel().getColumn(1).setPreferredWidth(109);
		tblSituacao.getColumnModel().getColumn(2).setPreferredWidth(327);
		tblSituacao.getColumnModel().getColumn(3).setPreferredWidth(157);
		tblSituacao.getColumnModel().getColumn(3).setMinWidth(75);
		
		scrollPane.setViewportView(tblSituacao);
		
		JLabel lblInserirNovaSituao = new JLabel("Inserir nova situa\u00E7\u00E3o da venda");
		lblInserirNovaSituao.setBounds(20, 158, 168, 25);
		panel.add(lblInserirNovaSituao);
		
		JLabel lblSelecioneAVenda = new JLabel("Selecione a venda");
		lblSelecioneAVenda.setBounds(20, 23, 135, 25);
		panel.add(lblSelecioneAVenda);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(119, 214, 89, 23);
		panel.add(btnCancelar);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(218, 214, 89, 23);
		panel.add(btnVoltar);
		
		btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					Situacao situacao = new Situacao();
					SituacaoController situacaoController = new SituacaoController();
					situacao.setIdSituacao((int) tblSituacao.getValueAt(tblSituacao.getSelectedRow(), 0));
					
					situacaoController.atualizaSituacaoDescricaoController(situacao);
					atualizarTabela();
				
			}
		});
		btnAtualizar.setBounds(18, 214, 89, 23);
		panel.add(btnAtualizar);
		
		
	}
public void atualizarTabela() {
		
		Object colunas [] = {"IDVenda", "Data da Venda", "Cliente", "Situa\u00E7\u00E3o"};
		DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
		
		VendaController vendaController = new VendaController();

		for (Map.Entry<Integer,Venda> pair : vendaController.buscarVendaController().entrySet()) {
			Venda venda = pair.getValue();
			Object linha[] = new Object[]{venda.getIdVenda(),venda.getDataVenda(),venda.getCliente().getNome(),
					 venda.getSituacao().getDescricao()};

			modelo.addRow(linha);
			//System.out.println(pair.getValue().getCliente().getNome());
		}
		tblSituacao.setModel(modelo);
	}
}

