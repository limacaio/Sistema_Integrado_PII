package Controller;

import java.util.ArrayList;
import java.util.HashMap;

import DAO.SituacaoDAO;
import Model.Situacao;



public class SituacaoController {
	public HashMap<Integer, Situacao> buscarSituacaoController(){
		return new SituacaoDAO().buscarSituacaoDAO();
	}
public void atualizaSituacaoDescricaoController(Situacao situacao) {
		SituacaoDAO situacaoDAO = new SituacaoDAO();
		
		if(situacaoDAO.atualizarDescricaoDAO(situacao)) {
			System.out.println("AtualizaDO COM SUCESSO");
		}else {
			System.out.println("Erro na atualiza��o");
		}

}
}