package Controller;

import java.util.ArrayList;
import java.util.HashMap;

import DAO.SituacaoDAO;
import Model.Situacao;



public class SituacaoController {
	public HashMap<Integer, Situacao> buscarSituacaoController(){
		return new SituacaoDAO().buscarSituacaoDAO();
	}

}