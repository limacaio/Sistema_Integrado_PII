package Controller;

import java.util.HashMap;

import DAO.VendaDAO;
import Model.Venda;

public class VendaController {

	public HashMap<Integer, Venda> buscarVendaController(){
		return new VendaDAO().buscarVendaDAO();
	}
	
}
