package Controller;

import java.util.HashMap;

import DAO.ClienteDAO;
import Model.Cliente;


public class ClienteController {
	
	public HashMap<Integer, Cliente> buscarClienteController(){
		return new ClienteDAO().buscarClienteDAO();
	}

}
