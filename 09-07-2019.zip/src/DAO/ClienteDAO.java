package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import Model.Cliente;
import Model.Situacao;
import Model.Venda;

public class ClienteDAO {
private Connection con = null;
	
	public ClienteDAO() {
		con = ConnectionDB.getConnection();
	}
	
public HashMap<Integer, Cliente> buscarClienteDAO(){
		
		String sql = "SELECT * FROM cliente";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		HashMap<Integer, Cliente> clienteList = new HashMap<>();
		
		try {
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			
			while (rs.next()) {
				Cliente cliente = new Cliente();
				
				//situacao.setIdSituacao(rs.getInt(situacao.SITUACAO_ID));
				cliente.setIdCLiente(rs.getInt(Cliente.ID_CLIENTE));
				cliente.setNome(rs.getString(Cliente.NOME));
				cliente.setCpf(rs.getString(Cliente.CPF));
				cliente.setTelefone(rs.getString(Cliente.TELEFONE));
				cliente.setCelular(rs.getString(Cliente.CELULAR));
				cliente.setEmail(rs.getString(Cliente.EMAIL));
				cliente.setSenha(rs.getString(Cliente.SENHA));
				cliente.setDtNascimento(rs.getDate(Cliente.DATA_NASCIMENTO));
				
				
				
				clienteList.put(cliente.getIdCLiente(), cliente);
			}
		} catch (SQLException ex) {
			System.out.println("Erro ao buscar SituacaoDAO" + ex);
		}finally {
			ConnectionDB.closeConnection(con, stmt, rs);
		}
		return clienteList;
		
	}
}
