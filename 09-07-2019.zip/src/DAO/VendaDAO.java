package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import Controller.ClienteController;
import Controller.SituacaoController;
import Model.Cliente;
import Model.Situacao;
import Model.Venda;

public class VendaDAO {
	
private Connection con = null;
	
	public VendaDAO() {
		con = ConnectionDB.getConnection();
	}
	
public HashMap<Integer, Venda> buscarVendaDAO(){
		
		String sql = "SELECT * FROM vendas ORDER BY data";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		HashMap<Integer, Cliente> clientes = new ClienteController().buscarClienteController();
		HashMap<Integer, Situacao> situacoes = new SituacaoController().buscarSituacaoController();
		HashMap<Integer, Venda> vendaList = new HashMap<>();
		
		try {
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			
			while (rs.next()) {
				Venda venda = new Venda();
				
				//situacao.setIdSituacao(rs.getInt(situacao.SITUACAO_ID));
				venda.setIdVenda(rs.getInt(Venda.ID_VENDA));
				venda.setCliente(clientes.get(rs.getInt(Venda.ID_CLIENTE)));
				venda.setDataVenda(rs.getDate(Venda.DATA));
				venda.setSituacao(situacoes.get(rs.getInt(Venda.ID_SITUACAO)));
				
				
				
				vendaList.put(venda.getIdVenda(), venda);
			}
		} catch (SQLException ex) {
			System.out.println("Erro ao buscar SituacaoDAO" + ex);
		}finally {
			ConnectionDB.closeConnection(con, stmt, rs);
		}
		return vendaList;
		
	}

}
